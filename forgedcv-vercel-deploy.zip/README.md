# forgedCV

forgedCV is a browser-local resume builder with live preview, PDF printing, resume scoring, cover-letter tools, and a LinkedIn profile PDF importer.

## Run locally

Requirements: Node.js 22 or newer and npm.

```powershell
npm ci
npm run dev
```

Open `http://localhost:3000`.

## Deploy to Vercel

1. Import this GitHub repository into Vercel.
2. Set the project root to the folder containing this `package.json`.
3. Keep the framework preset as Next.js.
4. Use `npm run build` as the build command. Vercel detects the Next.js output automatically.
5. No database or resume-storage environment variables are required for this release.
6. Deploy a Preview first, verify the builder, backup/restore, PDF output, and legal pages, then promote the approved commit to Production.

Resume drafts are stored in the visitor's browser and are not synchronized between devices. Users can download and restore a JSON backup from the editor's data menu. Clearing the current draft replaces it with a blank local draft.

## Checks

```powershell
npm run lint
npm run typecheck
npm test
npm run build
npm audit --audit-level=moderate
```

GitHub Actions runs these checks for pull requests and pushes to `main`.