import type { Metadata } from "next";
import { SiteHeader } from "@/components/site/SiteHeader";
import { SiteFooter } from "@/components/site/SiteFooter";

export const metadata: Metadata = {
  title: "Privacy",
  description: "How forgedCV handles resume content, browser storage, and imported files.",
  alternates: { canonical: "/privacy" },
};

export default function PrivacyPage() {
  return (
    <div className="flex min-h-screen flex-col bg-background">
      <SiteHeader />
      <main className="mx-auto w-full max-w-3xl flex-1 px-5 py-12 sm:px-8 sm:py-16">
        <p className="eyebrow">Privacy</p>
        <h1 className="display-heading mt-3 text-4xl text-foreground sm:text-5xl">Your resume is yours.</h1>
        <p className="mt-4 text-sm text-muted-foreground">Last updated: September 26, 2026</p>

        <div className="prose-flowcv mt-10">
          <h2>Resume content and browser storage</h2>
          <p>
            forgedCV keeps the resume you edit in this browser using local browser storage. The resume editor does not send that content to a forgedCV resume database. Anyone with access to the same browser profile may be able to access its stored data, and clearing browser data may remove it. Use <strong>Download backup</strong> in the editor to keep a copy, and use <strong>Clear local resume</strong> to replace the current draft with a blank one.
          </p>

          <h2>Files and analysis</h2>
          <p>
            Resume scoring and LinkedIn profile PDF extraction run in your browser. Imported text becomes part of the current local draft. Backup files are read locally and are not uploaded by the restore feature. Downloading or printing creates a file on your device.
          </p>

          <h2>Website requests</h2>
          <p>
            Loading forgedCV requires ordinary web requests to our hosting provider. Those requests can include technical information such as your IP address, browser, and requested page, as handled by the hosting provider. This site does not currently offer account-based cloud resume storage or cross-device synchronization.
          </p>

          <h2>Your choices</h2>
          <p>
            You can clear the draft in the editor, remove site data through your browser settings, or export a JSON backup before changing devices. To ask a privacy question, contact the forgedCV site operator through the published support channel.
          </p>

          <h2>Changes</h2>
          <p>
            This notice may change as the product changes. The date above indicates the latest revision.
          </p>
        </div>
      </main>
      <SiteFooter />
    </div>
  );
}