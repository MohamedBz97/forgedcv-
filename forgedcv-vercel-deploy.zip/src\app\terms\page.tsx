import type { Metadata } from "next";
import { SiteHeader } from "@/components/site/SiteHeader";
import { SiteFooter } from "@/components/site/SiteFooter";

export const metadata: Metadata = {
  title: "Terms of Use",
  description: "Terms for using forgedCV's resume builder and career tools.",
  alternates: { canonical: "/terms" },
};

export default function TermsPage() {
  return (
    <div className="flex min-h-screen flex-col bg-background">
      <SiteHeader />
      <main className="mx-auto w-full max-w-3xl flex-1 px-5 py-12 sm:px-8 sm:py-16">
        <p className="eyebrow">Terms</p>
        <h1 className="display-heading mt-3 text-4xl text-foreground sm:text-5xl">Terms of use</h1>
        <p className="mt-4 text-sm text-muted-foreground">Last updated: September 26, 2026</p>

        <div className="prose-flowcv mt-10">
          <h2>Using forgedCV</h2>
          <p>
            You may use forgedCV to create, edit, import, and export your own resume and career materials. You are responsible for the accuracy, legality, and appropriate use of the content you provide and download. Do not use the site to upload content you do not have the right to use or to interfere with the service or other users.
          </p>

          <h2>Local data and backups</h2>
          <p>
            Resume drafts are stored in the browser you use and are not a cloud backup. You are responsible for exporting and protecting your own backup files. We cannot restore content after it is cleared from your browser or device.
          </p>

          <h2>Career tools and results</h2>
          <p>
            Resume scores, writing suggestions, and template labels are general guidance based on automated checks. They are not professional recruiting advice, do not predict hiring outcomes, and do not guarantee that an applicant tracking system or employer will accept or rank a resume in a particular way. Review all generated, imported, and exported content before using it.
          </p>

          <h2>Availability and changes</h2>
          <p>
            We may update, suspend, or discontinue features as the service evolves. forgedCV is provided without a promise of uninterrupted availability. These terms may also be updated; continued use after a revision means you accept the updated terms.
          </p>

          <h2>Contact</h2>
          <p>
            For questions about these terms, contact the forgedCV site operator through the published support channel.
          </p>
        </div>
      </main>
      <SiteFooter />
    </div>
  );
}